package com.example.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.WebPreferences
import com.example.ui.components.AboutDialog
import com.example.ui.components.UrlSettingsDialog
import com.example.ui.components.WebErrorView
import com.example.ui.components.WebTopBar
import com.example.util.BlobDownloadManager
import kotlinx.coroutines.launch

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebScreen(
    initialUrl: String,
    onShowFileChooser: ((ValueCallback<Array<Uri>>?, WebChromeClient.FileChooserParams?) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val preferences = remember { WebPreferences(context) }

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    val blobDownloadManager = remember {
        BlobDownloadManager(context) { webViewInstance }
    }

    var currentUrl by remember { mutableStateOf(initialUrl) }
    var currentTitle by remember { mutableStateOf("Natok Explain") }
    var progress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(true) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isDesktopMode by remember { mutableStateOf(preferences.isDesktopMode) }

    var showUrlDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    // Full screen video handling
    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    // Double-back exit prevention
    var backPressedTime by remember { mutableStateOf(0L) }

    BackHandler {
        if (customView != null) {
            customViewCallback?.onCustomViewHidden()
            customView = null
            customViewCallback = null
            (context as? Activity)?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            val currentTime = System.currentTimeMillis()
            if (currentTime - backPressedTime < 2000) {
                (context as? Activity)?.finish()
            } else {
                backPressedTime = currentTime
                Toast.makeText(context, "অ্যাপ থেকে বের হতে আবার ব্যাক চাপুন", Toast.LENGTH_SHORT).show()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewInstance?.stopLoading()
            webViewInstance?.destroy()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("web_screen_scaffold"),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (customView == null) {
                Column {
                    WebTopBar(
                        currentTitle = currentTitle,
                        currentUrl = currentUrl,
                        isLoading = isLoading,
                        canGoBack = canGoBack,
                        canGoForward = canGoForward,
                        isDesktopMode = isDesktopMode,
                        onBackClick = { webViewInstance?.goBack() },
                        onForwardClick = { webViewInstance?.goForward() },
                        onRefreshClick = {
                            hasError = false
                            webViewInstance?.reload()
                        },
                        onStopClick = { webViewInstance?.stopLoading() },
                        onHomeClick = {
                            hasError = false
                            currentUrl = WebPreferences.DEFAULT_URL
                            preferences.currentUrl = WebPreferences.DEFAULT_URL
                            webViewInstance?.loadUrl(WebPreferences.DEFAULT_URL)
                        },
                        onToggleDesktopMode = {
                            val newMode = !isDesktopMode
                            isDesktopMode = newMode
                            preferences.isDesktopMode = newMode
                            webViewInstance?.settings?.let { settings ->
                                if (newMode) {
                                    settings.userAgentString = WebPreferences.DESKTOP_USER_AGENT
                                } else {
                                    settings.userAgentString = null
                                }
                            }
                            webViewInstance?.reload()
                            val msg = if (newMode) "ডেস্কটপ মোড চালু হয়েছে" else "মোবাইল মোড চালু হয়েছে"
                            coroutineScope.launch { snackbarHostState.showSnackbar(msg) }
                        },
                        onOpenInBrowser = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("ব্রাউজার খুলতে সমস্যা হয়েছে")
                                }
                            }
                        },
                        onShareUrl = {
                            try {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, currentTitle)
                                    putExtra(Intent.EXTRA_TEXT, "$currentTitle\n$currentUrl")
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "শেয়ার করুন"))
                            } catch (e: Exception) {
                                Toast.makeText(context, "শেয়ার করা সম্ভব হয়নি", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onCopyUrl = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("URL", currentUrl)
                            clipboard.setPrimaryClip(clip)
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("লিংক ক্লিপবোর্ডে কপি করা হয়েছে")
                            }
                        },
                        onClearCache = {
                            webViewInstance?.clearCache(true)
                            CookieManager.getInstance().removeAllCookies(null)
                            CookieManager.getInstance().flush()
                            webViewInstance?.reload()
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("ক্যাশ ও কুকিজ পরিষ্কার করা হয়েছে")
                            }
                        },
                        onOpenUrlSettings = { showUrlDialog = true },
                        onOpenAbout = { showAboutDialog = true }
                    )

                    AnimatedVisibility(
                        visible = isLoading && progress > 0f && progress < 1f,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .testTag("web_loading_progress"),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )

                        addJavascriptInterface(blobDownloadManager, "AndroidBlobBridge")

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            allowFileAccess = true
                            allowContentAccess = true
                            loadWithOverviewMode = true
                            useWideViewPort = true
                            setSupportZoom(true)
                            builtInZoomControls = true
                            displayZoomControls = false
                            mediaPlaybackRequiresUserGesture = false
                            cacheMode = WebSettings.LOAD_DEFAULT
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            safeBrowsingEnabled = false
                            if (isDesktopMode) {
                                userAgentString = WebPreferences.DESKTOP_USER_AGENT
                            }
                        }

                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                progress = newProgress / 100f
                                isLoading = newProgress < 100
                                if (view != null) {
                                    canGoBack = view.canGoBack()
                                    canGoForward = view.canGoForward()
                                }
                            }

                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                if (!title.isNullOrBlank()) {
                                    currentTitle = title
                                }
                            }

                            override fun onPermissionRequest(request: PermissionRequest?) {
                                request?.grant(request.resources)
                            }

                            override fun onShowFileChooser(
                                webView: WebView?,
                                filePathCallback: ValueCallback<Array<Uri>>?,
                                fileChooserParams: FileChooserParams?
                            ): Boolean {
                                return if (onShowFileChooser != null) {
                                    onShowFileChooser(filePathCallback, fileChooserParams)
                                    true
                                } else {
                                    super.onShowFileChooser(webView, filePathCallback, fileChooserParams)
                                }
                            }

                            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                                customView = view
                                customViewCallback = callback
                                (context as? Activity)?.requestedOrientation =
                                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            }

                            override fun onHideCustomView() {
                                customViewCallback?.onCustomViewHidden()
                                customView = null
                                customViewCallback = null
                                (context as? Activity)?.requestedOrientation =
                                    ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            }

                            override fun onGeolocationPermissionsShowPrompt(
                                origin: String?,
                                callback: GeolocationPermissions.Callback?
                            ) {
                                callback?.invoke(origin, true, false)
                            }
                        }

                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean {
                                val targetUri = request?.url ?: return false
                                val scheme = targetUri.scheme?.lowercase() ?: ""

                                return when (scheme) {
                                    "blob" -> {
                                        blobDownloadManager.triggerBlobDownload(
                                            this@apply,
                                            targetUri.toString(),
                                            "Natok_Explain_${System.currentTimeMillis()}.mp4",
                                            "video/mp4"
                                        )
                                        true
                                    }
                                    "http", "https" -> {
                                        false
                                    }
                                    else -> {
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, targetUri)
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "অ্যাপটি খুলতে ব্যর্থ হয়েছে", Toast.LENGTH_SHORT).show()
                                        }
                                        true
                                    }
                                }
                            }

                            override fun onPageStarted(
                                view: WebView?,
                                url: String?,
                                favicon: android.graphics.Bitmap?
                            ) {
                                isLoading = true
                                hasError = false
                                if (url != null) {
                                    currentUrl = url
                                }
                                if (view != null) {
                                    canGoBack = view.canGoBack()
                                    canGoForward = view.canGoForward()
                                }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                isLoading = false
                                if (url != null) {
                                    currentUrl = url
                                }
                                if (view != null) {
                                    canGoBack = view.canGoBack()
                                    canGoForward = view.canGoForward()
                                    val pageTitle = view.title
                                    if (!pageTitle.isNullOrBlank()) {
                                        currentTitle = pageTitle
                                    }

                                    // Inject script to catch blob download anchor clicks
                                    val script = """
                                        (function() {
                                            if (window.__blobDownloaderInjected) return;
                                            window.__blobDownloaderInjected = true;
                                            document.addEventListener('click', function(e) {
                                                var el = e.target;
                                                while (el && el.tagName !== 'A') {
                                                    el = el.parentElement;
                                                }
                                                if (el && el.href && el.href.startsWith('blob:')) {
                                                    var fname = el.getAttribute('download') || 'Natok_Video.mp4';
                                                    AndroidBlobBridge.requestBlobDownload(el.href, fname);
                                                }
                                            }, true);
                                        })();
                                    """.trimIndent()
                                    view.evaluateJavascript(script, null)
                                }
                            }

                            override fun onReceivedSslError(
                                view: WebView?,
                                handler: android.webkit.SslErrorHandler?,
                                error: android.net.http.SslError?
                            ) {
                                handler?.proceed()
                            }

                            override fun onReceivedError(
                                view: WebView?,
                                request: WebResourceRequest?,
                                error: WebResourceError?
                            ) {
                                if (request?.isForMainFrame == true) {
                                    hasError = true
                                    errorMessage = error?.description?.toString()
                                }
                            }
                        }

                        setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
                            try {
                                if (url.startsWith("blob:")) {
                                    val guessed = URLUtil.guessFileName(url, contentDisposition, mimetype)
                                    val filename = if (guessed.endsWith(".bin") || guessed == "downloadfile.bin") {
                                        "Natok_Explain_${System.currentTimeMillis()}.mp4"
                                    } else {
                                        guessed
                                    }
                                    blobDownloadManager.triggerBlobDownload(
                                        this,
                                        url,
                                        filename,
                                        mimetype
                                    )
                                } else {
                                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                                        setMimeType(mimetype)
                                        val cookies = CookieManager.getInstance().getCookie(url)
                                        addRequestHeader("cookie", cookies)
                                        addRequestHeader("User-Agent", userAgent)
                                        setDescription("Downloading file...")
                                        val filename = URLUtil.guessFileName(url, contentDisposition, mimetype)
                                        setTitle(filename)
                                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        setDestinationInExternalPublicDir(
                                            Environment.DIRECTORY_DOWNLOADS,
                                            filename
                                        )
                                    }
                                    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                    dm.enqueue(request)
                                    Toast.makeText(context, "ডাউনলোড শুরু হয়েছে...", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "ডাউনলোড শুরু করা যায়নি: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                            }
                        }

                        loadUrl(currentUrl)
                        webViewInstance = this
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("main_web_view")
            )

            // Error Overlay
            if (hasError) {
                WebErrorView(
                    errorMessage = errorMessage,
                    onRetry = {
                        hasError = false
                        webViewInstance?.reload()
                    },
                    onGoHome = {
                        hasError = false
                        currentUrl = WebPreferences.DEFAULT_URL
                        preferences.currentUrl = WebPreferences.DEFAULT_URL
                        webViewInstance?.loadUrl(WebPreferences.DEFAULT_URL)
                    },
                    onLoadBackup = {
                        hasError = false
                        currentUrl = WebPreferences.RUBEL_NATOK_URL
                        preferences.currentUrl = WebPreferences.RUBEL_NATOK_URL
                        webViewInstance?.loadUrl(WebPreferences.RUBEL_NATOK_URL)
                    }
                )
            }

            // Fullscreen video overlay
            if (customView != null) {
                AndroidView(
                    factory = {
                        FrameLayout(it).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            (customView?.parent as? ViewGroup)?.removeView(customView)
                            addView(customView)
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .testTag("fullscreen_video_view")
                )
            }
        }
    }

    if (showUrlDialog) {
        UrlSettingsDialog(
            initialUrl = currentUrl,
            onDismiss = { showUrlDialog = false },
            onUrlConfirmed = { newUrl ->
                showUrlDialog = false
                currentUrl = newUrl
                preferences.currentUrl = newUrl
                hasError = false
                webViewInstance?.loadUrl(newUrl)
            }
        )
    }

    if (showAboutDialog) {
        AboutDialog(
            onDismiss = { showAboutDialog = false }
        )
    }
}
