package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.WebPreferences

@Composable
fun UrlSettingsDialog(
    initialUrl: String,
    onDismiss: () -> Unit,
    onUrlConfirmed: (String) -> Unit
) {
    var urlText by remember { mutableStateOf(initialUrl) }
    var isError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("url_settings_dialog"),
        icon = {
            Icon(
                imageVector = Icons.Default.Language,
                contentDescription = "URL Settings",
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text(
                text = "ওয়েবসাইট / অ্যাপ সোর্স",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "অনলাইন সাইট বা লোকাল HTML অ্যাপের উৎস নির্বাচন করুন:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = urlText,
                    onValueChange = {
                        urlText = it
                        isError = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("url_input_field"),
                    label = { Text("ওয়েবসাইট URL বা লোকাল পাথ") },
                    placeholder = { Text("https://...") },
                    singleLine = false,
                    maxLines = 3,
                    isError = isError,
                    supportingText = {
                        if (isError) {
                            Text("একটি সঠিক URL লিখুন")
                        }
                    },
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "দ্রুত প্রিসেট (Quick Presets):",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = {
                        urlText = WebPreferences.LOCAL_APP_URL
                        isError = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("preset_local_html_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = "Local HTML",
                        modifier = Modifier.padding(end = 6.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text("লোকাল স্টুডিও v3.7 (Offline HTML)")
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = {
                        urlText = WebPreferences.DEFAULT_URL
                        isError = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("preset_rubel_natok_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Restore,
                        contentDescription = "Rubel Natok",
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text("অনলাইন সার্ভার (ai.studio)")
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = {
                        urlText = WebPreferences.HABIB_YT_URL
                        isError = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("preset_habib_yt_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = "YouTube",
                        modifier = Modifier.padding(end = 6.dp),
                        tint = MaterialTheme.colorScheme.error
                    )
                    Text("Habib YouTube Channel")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = WebPreferences.parseUrlInput(urlText)
                    onUrlConfirmed(parsed)
                },
                modifier = Modifier.testTag("save_url_button")
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_url_button")
            ) {
                Text("বাতিল")
            }
        }
    )
}
