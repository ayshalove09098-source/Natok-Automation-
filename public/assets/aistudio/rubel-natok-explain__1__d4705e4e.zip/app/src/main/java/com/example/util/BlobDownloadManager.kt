package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

class BlobDownloadManager(
    private val context: Context,
    private val webViewProvider: () -> WebView?
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private data class TransferState(
        val tempFile: File,
        val outputStream: FileOutputStream,
        val filename: String,
        val mimeType: String,
        val totalSize: Long,
        var bytesWritten: Long = 0L
    )

    private val activeTransfers = ConcurrentHashMap<String, TransferState>()

    @JavascriptInterface
    fun requestBlobDownload(blobUrl: String, filename: String) {
        mainHandler.post {
            val wv = webViewProvider() ?: return@post
            val cleanName = sanitizeFilename(filename)
            triggerBlobDownload(wv, blobUrl, cleanName, "video/mp4")
        }
    }

    @JavascriptInterface
    fun startBlobTransfer(transferId: String, filename: String, mimeType: String, totalSize: Long) {
        try {
            val cleanName = sanitizeFilename(filename)
            val cleanMime = if (mimeType.isNotBlank() && mimeType != "undefined") mimeType else "video/mp4"
            val tempFile = File.createTempFile("blob_down_", ".tmp", context.cacheDir)
            val outputStream = FileOutputStream(tempFile)
            activeTransfers[transferId] = TransferState(
                tempFile = tempFile,
                outputStream = outputStream,
                filename = cleanName,
                mimeType = cleanMime,
                totalSize = totalSize
            )
            mainHandler.post {
                Toast.makeText(context, "ভিডিও ডাউনলোড শুরু হয়েছে...", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            mainHandler.post {
                Toast.makeText(context, "ডাউনলোড শুরু ব্যর্থ: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun appendBlobChunk(transferId: String, base64Chunk: String) {
        val state = activeTransfers[transferId] ?: return
        try {
            val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
            state.outputStream.write(bytes)
            state.bytesWritten += bytes.size
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun finishBlobTransfer(transferId: String) {
        val state = activeTransfers.remove(transferId) ?: return
        try {
            state.outputStream.flush()
            state.outputStream.close()

            val savedUri = saveToGalleryAndDownloads(state.tempFile, state.filename, state.mimeType)
            state.tempFile.delete()

            mainHandler.post {
                Toast.makeText(
                    context,
                    "ভিডিও ডাউনলোড সম্পন্ন হয়েছে!\n${state.filename}",
                    Toast.LENGTH_LONG
                ).show()

                // If saved successfully, try to offer open intent or scan
                if (savedUri != null) {
                    try {
                        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(savedUri, state.mimeType)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(viewIntent)
                    } catch (e: Exception) {
                        // Player not available or user cancelled, file is safely saved
                    }
                }
            }
        } catch (e: Exception) {
            mainHandler.post {
                Toast.makeText(context, "ভিডিও সংরক্ষণে সমস্যা হয়েছে: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @JavascriptInterface
    fun onBlobError(errorMessage: String) {
        mainHandler.post {
            Toast.makeText(context, "ডাউনলোড এরর: $errorMessage", Toast.LENGTH_SHORT).show()
        }
    }

    fun triggerBlobDownload(
        webView: WebView,
        blobUrl: String,
        suggestedFilename: String?,
        suggestedMimeType: String?
    ) {
        val filename = sanitizeFilename(suggestedFilename ?: "Natok_Explain_${System.currentTimeMillis()}.mp4")
        val mime = if (!suggestedMimeType.isNullOrBlank()) suggestedMimeType else "video/mp4"

        val js = """
            (async function() {
                try {
                    const res = await fetch('$blobUrl');
                    const blob = await res.blob();
                    const totalSize = blob.size;
                    const mime = blob.type || '$mime';
                    const fname = '$filename';
                    const txId = 'tx_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
                    
                    AndroidBlobBridge.startBlobTransfer(txId, fname, mime, totalSize);
                    
                    const chunkSize = 256 * 1024;
                    let offset = 0;
                    
                    while (offset < totalSize) {
                        const slice = blob.slice(offset, offset + chunkSize);
                        const reader = new FileReader();
                        const chunkPromise = new Promise((resolve, reject) => {
                            reader.onloadend = () => {
                                const dataUrl = reader.result || '';
                                const commaIdx = dataUrl.indexOf(',');
                                const b64 = commaIdx >= 0 ? dataUrl.substring(commaIdx + 1) : '';
                                resolve(b64);
                            };
                            reader.onerror = reject;
                        });
                        reader.readAsDataURL(slice);
                        const b64Data = await chunkPromise;
                        AndroidBlobBridge.appendBlobChunk(txId, b64Data);
                        offset += chunkSize;
                    }
                    AndroidBlobBridge.finishBlobTransfer(txId);
                } catch(err) {
                    AndroidBlobBridge.onBlobError(err.toString());
                }
            })();
        """.trimIndent()

        webView.evaluateJavascript(js, null)
    }

    private fun saveToGalleryAndDownloads(tempFile: File, filename: String, mimeType: String): Uri? {
        val isVideo = mimeType.startsWith("video") || filename.endsWith(".mp4") || filename.endsWith(".mkv")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val collection = if (isVideo) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                if (isVideo) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/NatokExplain")
                } else {
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(collection, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    tempFile.inputStream().use { input -> input.copyTo(out) }
                }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                return uri
            }
        }

        val targetDir = if (isVideo) {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
        } else {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        }
        targetDir.mkdirs()
        val destFile = File(targetDir, filename)
        tempFile.copyTo(destFile, overwrite = true)
        MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf(mimeType), null)
        return Uri.fromFile(destFile)
    }

    private fun sanitizeFilename(input: String): String {
        val clean = input.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return if (clean.isBlank() || clean == "_" || clean == "downloadfile.bin") {
            "Natok_Explain_${System.currentTimeMillis()}.mp4"
        } else if (!clean.contains(".")) {
            "$clean.mp4"
        } else {
            clean
        }
    }
}
