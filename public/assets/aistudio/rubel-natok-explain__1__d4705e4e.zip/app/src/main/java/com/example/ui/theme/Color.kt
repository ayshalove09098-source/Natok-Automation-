package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val PrimaryIndigo = Color(0xFF4F46E5)
val PrimaryIndigoLight = Color(0xFF818CF8)
val PrimaryIndigoDark = Color(0xFF3730A3)

val AccentRuby = Color(0xFFE11D48)
val AccentRubyLight = Color(0xFFFB7185)

val SurfaceDark = Color(0xFF0B1120)
val SurfaceContainerDark = Color(0xFF151E32)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceContainerLight = Color(0xFFF8FAFC)
