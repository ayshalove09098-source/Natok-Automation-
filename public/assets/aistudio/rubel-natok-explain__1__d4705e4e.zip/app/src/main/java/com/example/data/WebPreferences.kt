package com.example.data

import android.content.Context
import android.content.SharedPreferences
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class WebPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var currentUrl: String
        get() = prefs.getString(KEY_CURRENT_URL, DEFAULT_URL) ?: DEFAULT_URL
        set(value) {
            prefs.edit().putString(KEY_CURRENT_URL, value).apply()
        }

    var isDesktopMode: Boolean
        get() = prefs.getBoolean(KEY_DESKTOP_MODE, false)
        set(value) {
            prefs.edit().putBoolean(KEY_DESKTOP_MODE, value).apply()
        }

    fun resetToDefault() {
        prefs.edit()
            .putString(KEY_CURRENT_URL, DEFAULT_URL)
            .putBoolean(KEY_DESKTOP_MODE, false)
            .apply()
    }

    companion object {
        const val PREFS_NAME = "rubel_natok_prefs_v6"
        const val LOCAL_APP_URL = "file:///android_asset/index.html"
        const val DEFAULT_URL = "https://rubel-vai-natok-explain-automotion-v3-7.ai.studio/"
        const val RUBEL_NATOK_URL = DEFAULT_URL
        const val HABIB_YT_URL = "https://www.youtube.com/results?search_query=habib+automation"
        const val HABIB_CHANNEL_URL = "https://www.youtube.com/@habibautomation"

        const val KEY_CURRENT_URL = "key_target_url"
        const val KEY_DESKTOP_MODE = "key_desktop_mode"

        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

        fun parseUrlInput(input: String): String {
            var trimmed = input.trim()
            if (trimmed.isEmpty()) return DEFAULT_URL

            if (trimmed.contains("automotionai.studio")) {
                trimmed = trimmed.replace("automotionai.studio", "automotion.ai.studio")
            }

            if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("file://")) {
                return trimmed
            }

            if (trimmed.startsWith("@")) {
                return "https://www.youtube.com/$trimmed"
            }

            if (trimmed.contains(".") && !trimmed.contains(" ")) {
                return "https://$trimmed"
            }

            val encodedQuery = URLEncoder.encode(
                trimmed.replace(Regex("(?i)\\b(yt|youtube)\\b"), "").trim(),
                StandardCharsets.UTF_8.toString()
            )
            return "https://www.youtube.com/results?search_query=$encodedQuery"
        }
    }
}
