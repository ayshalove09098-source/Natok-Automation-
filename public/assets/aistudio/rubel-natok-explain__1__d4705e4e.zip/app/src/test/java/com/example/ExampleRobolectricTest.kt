package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.WebPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Natok Explain", appName)
  }

  @Test
  fun `verify web preferences default and update`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val preferences = WebPreferences(context)
    assertEquals(WebPreferences.DEFAULT_URL, preferences.currentUrl)
    assertFalse(preferences.isDesktopMode)

    preferences.isDesktopMode = true
    assertTrue(preferences.isDesktopMode)

    preferences.currentUrl = "https://example.com"
    assertEquals("https://example.com", preferences.currentUrl)

    preferences.resetToDefault()
    assertEquals(WebPreferences.DEFAULT_URL, preferences.currentUrl)
    assertFalse(preferences.isDesktopMode)
  }

  @Test
  fun `verify target website url is rubel natok explain`() {
    assertEquals(
      "https://rubel-vai-natok-explain-automotion-v3-7.ai.studio/",
      WebPreferences.DEFAULT_URL
    )
  }

  @Test
  fun `verify url normalization for missing dot`() {
    val parsed = WebPreferences.parseUrlInput("https://habib-yt-natok-automotionai.studio")
    assertEquals("https://habib-yt-natok-automotion.ai.studio", parsed)
  }
}
